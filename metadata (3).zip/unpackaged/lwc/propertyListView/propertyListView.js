import { LightningElement,wire, track } from 'lwc';
import getProperties from "@salesforce/apex/GetProperties.getPropertyRecords";
const COLUMNS = [
{ label: 'S.No', fieldName: 'rowNumber', type: 'number' },
{ label: 'Property Name', fieldName: 'Name' },
{ label: 'Type', fieldName: 'Type__c'},
{ label: 'Status', fieldName: 'Status__c'},
{ label: 'Rent Amount', fieldName: 'Rent__c'},
{ label: 'Furnishing Status', fieldName: 'Furnishing_Status__c'},
{ label: 'Description', fieldName: 'Description__c'}
];

const RECORDS_PER_PAGE = 5;

export default class PropertyListView extends LightningElement {

@track allData = []; // Stores all records
@track data = []; // Stores paginated records
@track filteredData = [];
columns = COLUMNS;
currentPage = 1;
totalPages = 0;
minRent = 0; // Default minimum rent
isDataLoaded = false; // To prevent filtering before data is loaded
selectedStatus = ''; // Default to show all statuses
selectedFurnishedStatus = '';//

@wire(getProperties)
wiredAccounts({ error, data }) {
    if (data) {
        console.log('data',data);
        this.allData = data;
        this.filteredData = [...data]; // Initialize with all data
        this.isDataLoaded = true;
        this.totalPages = Math.ceil(data.length / RECORDS_PER_PAGE);
        this.updatePagination();
    } else if (error) {
        console.error('Error fetching accounts:', error);
    }
}

updatePagination() {
    const start = (this.currentPage - 1) * RECORDS_PER_PAGE;
    const end = start + RECORDS_PER_PAGE;
    this.data = this.filteredData.slice(start, end).map((record, index) => ({
        ...record,
        rowNumber: start + index + 1 // 
    }));
    this.totalPages = Math.ceil(this.filteredData.length / RECORDS_PER_PAGE);
}

    // Handle Rent Amount Filter
    handleRentFilter(event) {
    this.minRent = event.target.value ? parseFloat(event.target.value) : 0;
    this.applyFilters();
}

// Handle Status Filter
handleStatusFilter(event) {
    this.selectedStatus = event.target.value;
    this.applyFilters();
}

handleFurnishedStatusFilter(event){

this.selectedFurnishedStatus = event.target.value;
this.applyFilters();
}

applyFilters() {
    if (!this.isDataLoaded) return; // Prevent filtering before data is loaded

    this.filteredData = this.allData.filter(Property_Management__c => 
        Property_Management__c.Rent__c >= this.minRent &&
        (this.selectedStatus === '' || Property_Management__c.Status__c === this.selectedStatus) &&
        (this.selectedFurnishedStatus === '' || Property_Management__c.Furnishing_Status__c === this.selectedFurnishedStatus)
    );
    this.currentPage = 1; // Reset to first page after filtering
    this.updatePagination();
}

previousPage() {
    if (this.currentPage > 1) {
        this.currentPage--;
        this.updatePagination();
    }
}
nextPage() {
    if (this.currentPage < this.totalPages) {
        this.currentPage++;
        this.updatePagination();
    }
}
get disablePrevious() {
    return this.currentPage <= 1;
}
get disableNext() {
    return this.currentPage >= this.totalPages;
}

//Status Picklist Options
get statusOptions() {
    return [
        { label: 'All', value: '' },
        { label: 'Occupied', value: 'Occupied' },
        { label: 'Available', value: 'Available' }
    ];
}
get FurnishedOptions() {
    return [
        { label: 'All', value: '' },
        { label: 'Furnished', value: 'Furnished' },
        { label: 'Semi-Furnished', value: 'Semi-Furnished' },
        { label: 'Unfurnished', value: 'Unfurnished' }
    ];
}

}